﻿using Microsoft.Extensions.Logging;
using HMI.Communication.Implementations;
using HMI.Communication.Models;

namespace HMI.Communication.Example
{
    class Program
    {
        static async Task Main(string[] args)
        {
            // 创建日志记录器
            using var loggerFactory = LoggerFactory.Create(builder =>
            {
                builder.AddConsole().SetMinimumLevel(LogLevel.Debug);
            });

            var logger = loggerFactory.CreateLogger<Program>();

            Console.WriteLine("=== HMI通讯库示例程序 ===");
            Console.WriteLine("1. 串口通讯示例");
            Console.WriteLine("2. TCP通讯示例");
            Console.WriteLine("请选择要测试的通讯方式 (1-2):");

            var choice = Console.ReadLine();

            switch (choice)
            {
                case "1":
                    await TestSerialPortCommunication(loggerFactory);
                    break;
                case "2":
                    await TestTcpCommunication(loggerFactory);
                    break;
                default:
                    Console.WriteLine("无效选择");
                    break;
            }

            Console.WriteLine("按任意键退出...");
            Console.ReadKey();
        }

        static async Task TestSerialPortCommunication(ILoggerFactory loggerFactory)
        {
            var logger = loggerFactory.CreateLogger<SerialPortDevice>();

            Console.WriteLine("\n=== 串口通讯测试 ===");
            Console.Write("请输入串口名称 (默认: COM1): ");
            var portName = Console.ReadLine();
            if (string.IsNullOrEmpty(portName))
                portName = "COM1";

            var config = new SerialPortConfiguration
            {
                DeviceName = "测试串口设备",
                DeviceId = "SERIAL_001",
                PortName = portName,
                BaudRate = 9600,
                Parity = System.IO.Ports.Parity.None,
                DataBits = 8,
                StopBits = System.IO.Ports.StopBits.One
            };

            using var device = new SerialPortDevice(config, logger);

            // 订阅事件
            device.ConnectionStatusChanged += (sender, e) =>
                Console.WriteLine($"连接状态变更: {(e.IsConnected ? "已连接" : "已断开")} - {e.Message}");

            device.DataReceived += (sender, e) =>
                Console.WriteLine($"收到数据: {Convert.ToHexString(e.Data)}");

            device.ErrorOccurred += (sender, e) =>
                Console.WriteLine($"发生错误: {e.Message}");

            // 连接设备
            Console.WriteLine("正在连接串口...");
            if (await device.ConnectAsync())
            {
                Console.WriteLine("串口连接成功!");

                // 发送测试数据
                var testData = new byte[] { 0x01, 0x03, 0x00, 0x00, 0x00, 0x01, 0x84, 0x0A };
                Console.WriteLine($"发送测试数据: {Convert.ToHexString(testData)}");

                var result = await device.SendAsync(testData);
                if (result.IsSuccess)
                {
                    Console.WriteLine($"数据发送成功，耗时: {result.ElapsedMilliseconds}ms");

                    // 尝试读取响应
                    var readResult = await device.ReadAsync(3000);
                    if (readResult.IsSuccess && readResult.Data != null)
                    {
                        Console.WriteLine($"读取到响应: {Convert.ToHexString(readResult.Data)}");
                    }
                    else
                    {
                        Console.WriteLine($"读取响应失败: {readResult.ErrorMessage}");
                    }
                }
                else
                {
                    Console.WriteLine($"数据发送失败: {result.ErrorMessage}");
                }
            }
            else
            {
                Console.WriteLine("串口连接失败!");
            }
        }

        static async Task TestTcpCommunication(ILoggerFactory loggerFactory)
        {
            var logger = loggerFactory.CreateLogger<TcpDevice>();

            Console.WriteLine("\n=== TCP通讯测试 ===");
            Console.Write("请输入服务器IP地址 (默认: 127.0.0.1): ");
            var ipAddress = Console.ReadLine();
            if (string.IsNullOrEmpty(ipAddress))
                ipAddress = "127.0.0.1";

            Console.Write("请输入端口号 (默认: 502): ");
            var portInput = Console.ReadLine();
            int port = 502;
            if (!string.IsNullOrEmpty(portInput))
                int.TryParse(portInput, out port);

            var config = new TcpConfiguration
            {
                DeviceName = "测试TCP设备",
                DeviceId = "TCP_001",
                IPAddress = ipAddress,
                Port = port,
                KeepAlive = true
            };

            using var device = new TcpDevice(config, logger);

            // 订阅事件
            device.ConnectionStatusChanged += (sender, e) =>
                Console.WriteLine($"连接状态变更: {(e.IsConnected ? "已连接" : "已断开")} - {e.Message}");

            device.DataReceived += (sender, e) =>
                Console.WriteLine($"收到数据: {Convert.ToHexString(e.Data)}");

            device.ErrorOccurred += (sender, e) =>
                Console.WriteLine($"发生错误: {e.Message}");

            // 连接设备
            Console.WriteLine($"正在连接TCP服务器 {ipAddress}:{port}...");
            if (await device.ConnectAsync())
            {
                Console.WriteLine("TCP连接成功!");

                // 发送测试数据
                var testData = new byte[] { 0x00, 0x01, 0x00, 0x00, 0x00, 0x06, 0x01, 0x03, 0x00, 0x00, 0x00, 0x01 };
                Console.WriteLine($"发送测试数据: {Convert.ToHexString(testData)}");

                var result = await device.SendAndReceiveAsync(testData, 5000);
                if (result.IsSuccess && result.Data != null)
                {
                    Console.WriteLine($"收到响应: {Convert.ToHexString(result.Data)}, 耗时: {result.ElapsedMilliseconds}ms");
                }
                else
                {
                    Console.WriteLine($"通讯失败: {result.ErrorMessage}");
                }

                // 等待一段时间以观察事件
                Console.WriteLine("等待10秒以观察连接状态...");
                await Task.Delay(10000);
            }
            else
            {
                Console.WriteLine("TCP连接失败!");
            }
        }
    }
}
