using System;
using System.Net;
using System.Net.Sockets;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.Extensions.Logging;
using HMI.Communication.Common;
using HMI.Communication.Interfaces;
using HMI.Communication.Models;

namespace HMI.Communication.Implementations
{
    /// <summary>
    /// TCP通讯实现
    /// </summary>
    public class TcpDevice : CommunicationBase, ICommunicationDevice
    {
        private TcpClient? _tcpClient;
        private NetworkStream? _networkStream;
        private readonly SemaphoreSlim _sendSemaphore = new(1, 1);
        private readonly SemaphoreSlim _readSemaphore = new(1, 1);
        private CancellationTokenSource? _cancellationTokenSource;

        public bool IsConnected => _tcpClient?.Connected == true;
        public DeviceConfiguration Configuration { get; }

        public event EventHandler<ConnectionStatusChangedEventArgs>? ConnectionStatusChanged;
        public event EventHandler<DataReceivedEventArgs>? DataReceived;
        public event EventHandler<CommunicationErrorEventArgs>? ErrorOccurred;

        public TcpDevice(TcpConfiguration configuration, ILogger<TcpDevice>? logger = null)
            : base(logger)
        {
            Configuration = configuration ?? throw new ArgumentNullException(nameof(configuration));
        }

        public async Task<bool> ConnectAsync()
        {
            ThrowIfDisposed();

            try
            {
                if (IsConnected)
                {
                    LogWarning("TCP已经连接");
                    return true;
                }

                var config = (TcpConfiguration)Configuration;

                _cancellationTokenSource = new CancellationTokenSource();
                _tcpClient = new TcpClient();

                // 设置KeepAlive
                if (config.KeepAlive)
                {
                    _tcpClient.Client.SetSocketOption(SocketOptionLevel.Socket, SocketOptionName.KeepAlive, true);
                }

                // 设置超时
                _tcpClient.ReceiveTimeout = config.ReceiveTimeout;
                _tcpClient.SendTimeout = config.SendTimeout;

                var endpoint = new IPEndPoint(IPAddress.Parse(config.IPAddress), config.Port);
                
                using var timeoutCts = new CancellationTokenSource(config.ConnectionTimeout);
                await _tcpClient.ConnectAsync(endpoint.Address, endpoint.Port, timeoutCts.Token);

                _networkStream = _tcpClient.GetStream();

                LogInformation("TCP连接成功: {IPAddress}:{Port}", config.IPAddress, config.Port);
                ConnectionStatusChanged?.Invoke(this, new ConnectionStatusChangedEventArgs(true, "连接成功"));

                // 启动数据接收监听
                _ = Task.Run(ListenForDataAsync, _cancellationTokenSource.Token);

                return true;
            }
            catch (Exception ex)
            {
                LogError("TCP连接失败", ex);
                OnErrorOccurred("TCP连接失败", ex);
                await CleanupConnectionAsync();
                return false;
            }
        }

        public async Task<bool> DisconnectAsync()
        {
            ThrowIfDisposed();

            try
            {
                if (!IsConnected)
                {
                    LogWarning("TCP未连接");
                    return true;
                }

                await CleanupConnectionAsync();

                LogInformation("TCP断开连接成功");
                ConnectionStatusChanged?.Invoke(this, new ConnectionStatusChangedEventArgs(false, "断开连接"));

                return true;
            }
            catch (Exception ex)
            {
                LogError("TCP断开连接失败", ex);
                OnErrorOccurred("TCP断开连接失败", ex);
                return false;
            }
        }

        public async Task<CommunicationResult> SendAsync(byte[] data)
        {
            ThrowIfDisposed();

            if (data == null || data.Length == 0)
                return CommunicationResult.Failure("发送数据为空");

            if (!IsConnected || _networkStream == null)
                return CommunicationResult.Failure("TCP未连接");

            var stopwatch = System.Diagnostics.Stopwatch.StartNew();

            try
            {
                await _sendSemaphore.WaitAsync();

                using var timeoutCts = new CancellationTokenSource(Configuration.SendTimeout);
                await _networkStream.WriteAsync(data, 0, data.Length, timeoutCts.Token);
                await _networkStream.FlushAsync(timeoutCts.Token);

                LogDebug("发送数据: {Data}", CommunicationUtils.BytesToHexString(data));

                stopwatch.Stop();
                return CommunicationResult.Success(elapsedMilliseconds: stopwatch.ElapsedMilliseconds);
            }
            catch (Exception ex)
            {
                stopwatch.Stop();
                LogError("发送数据失败", ex);
                return CommunicationResult.Failure("发送数据失败", ex, stopwatch.ElapsedMilliseconds);
            }
            finally
            {
                _sendSemaphore.Release();
            }
        }

        public async Task<CommunicationResult> ReadAsync(int timeout = 5000)
        {
            ThrowIfDisposed();

            if (!IsConnected || _networkStream == null)
                return CommunicationResult.Failure("TCP未连接");

            var stopwatch = System.Diagnostics.Stopwatch.StartNew();

            try
            {
                await _readSemaphore.WaitAsync();

                var buffer = new byte[1024];
                using var timeoutCts = new CancellationTokenSource(timeout);
                
                int bytesRead = await _networkStream.ReadAsync(buffer, 0, buffer.Length, timeoutCts.Token);

                if (bytesRead > 0)
                {
                    var data = new byte[bytesRead];
                    Array.Copy(buffer, data, bytesRead);

                    LogDebug("接收数据: {Data}", CommunicationUtils.BytesToHexString(data));

                    stopwatch.Stop();
                    return CommunicationResult.Success(data, stopwatch.ElapsedMilliseconds);
                }

                stopwatch.Stop();
                return CommunicationResult.Failure("未接收到数据", elapsedMilliseconds: stopwatch.ElapsedMilliseconds);
            }
            catch (OperationCanceledException)
            {
                stopwatch.Stop();
                return CommunicationResult.Failure("接收数据超时", elapsedMilliseconds: stopwatch.ElapsedMilliseconds);
            }
            catch (Exception ex)
            {
                stopwatch.Stop();
                LogError("接收数据失败", ex);
                return CommunicationResult.Failure("接收数据失败", ex, stopwatch.ElapsedMilliseconds);
            }
            finally
            {
                _readSemaphore.Release();
            }
        }

        public async Task<CommunicationResult> SendAndReceiveAsync(byte[] data, int timeout = 5000)
        {
            var sendResult = await SendAsync(data);
            if (!sendResult.IsSuccess)
                return sendResult;

            // 等待一小段时间让服务器处理请求
            await Task.Delay(10);

            return await ReadAsync(timeout);
        }

        private async Task ListenForDataAsync()
        {
            var buffer = new byte[1024];

            while (!_cancellationTokenSource?.Token.IsCancellationRequested == true && IsConnected)
            {
                try
                {
                    if (_networkStream?.DataAvailable == true)
                    {
                        int bytesRead = await _networkStream.ReadAsync(buffer, 0, buffer.Length, _cancellationTokenSource.Token);
                        
                        if (bytesRead > 0)
                        {
                            var data = new byte[bytesRead];
                            Array.Copy(buffer, data, bytesRead);

                            DataReceived?.Invoke(this, new DataReceivedEventArgs(data, Configuration.DeviceName));
                        }
                    }

                    await Task.Delay(10, _cancellationTokenSource.Token);
                }
                catch (OperationCanceledException)
                {
                    break;
                }
                catch (Exception ex)
                {
                    OnErrorOccurred("数据接收监听失败", ex);
                    break;
                }
            }
        }

        private async Task CleanupConnectionAsync()
        {
            try
            {
                _cancellationTokenSource?.Cancel();

                if (_networkStream != null)
                {
                    await _networkStream.DisposeAsync();
                    _networkStream = null;
                }

                _tcpClient?.Close();
                _tcpClient?.Dispose();
                _tcpClient = null;

                _cancellationTokenSource?.Dispose();
                _cancellationTokenSource = null;
            }
            catch (Exception ex)
            {
                LogError("清理TCP连接资源失败", ex);
            }
        }

        private void OnErrorOccurred(string message, Exception? exception = null)
        {
            LogError(message, exception);
            ErrorOccurred?.Invoke(this, new CommunicationErrorEventArgs(message, exception, Configuration.DeviceName));
        }

        public override void Dispose()
        {
            if (!_disposed)
            {
                DisconnectAsync().Wait(1000);

                _sendSemaphore?.Dispose();
                _readSemaphore?.Dispose();

                base.Dispose();
            }
        }
    }
}