using System;
using System.Net;
using System.Net.Sockets;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.Extensions.Logging;
using HMI.Communication.Common;
using HMI.Communication.Interfaces;
using HMI.Communication.Models;

namespace HMI.Communication.Implementations
{
    /// <summary>
    /// UDP通讯实现
    /// </summary>
    public class UdpDevice : CommunicationBase, ICommunicationDevice
    {
        private UdpClient? _udpClient;
        private IPEndPoint? _remoteEndPoint;
        private IPEndPoint? _localEndPoint;
        private readonly SemaphoreSlim _sendSemaphore = new(1, 1);
        private readonly SemaphoreSlim _readSemaphore = new(1, 1);
        private CancellationTokenSource? _cancellationTokenSource;

        public bool IsConnected { get; private set; }
        public DeviceConfiguration Configuration { get; }

        public event EventHandler<ConnectionStatusChangedEventArgs>? ConnectionStatusChanged;
        public event EventHandler<DataReceivedEventArgs>? DataReceived;
        public event EventHandler<CommunicationErrorEventArgs>? ErrorOccurred;

        public UdpDevice(UdpConfiguration configuration, ILogger<UdpDevice>? logger = null)
            : base(logger)
        {
            Configuration = configuration ?? throw new ArgumentNullException(nameof(configuration));
        }

        public async Task<bool> ConnectAsync()
        {
            ThrowIfDisposed();

            try
            {
                if (IsConnected)
                {
                    LogWarning("UDP已经连接");
                    return true;
                }

                var config = (UdpConfiguration)Configuration;

                // 创建本地端点
                var localAddress = IPAddress.Parse(config.LocalIPAddress);
                _localEndPoint = new IPEndPoint(localAddress, config.LocalPort);

                // 创建远程端点
                var remoteAddress = IPAddress.Parse(config.IPAddress);
                _remoteEndPoint = new IPEndPoint(remoteAddress, config.Port);

                // 创建UDP客户端
                _udpClient = new UdpClient(_localEndPoint);
                _udpClient.Client.ReceiveTimeout = config.ReceiveTimeout;
                _udpClient.Client.SendTimeout = config.SendTimeout;

                _cancellationTokenSource = new CancellationTokenSource();
                IsConnected = true;

                LogInformation("UDP连接成功: 本地={LocalEndPoint}, 远程={RemoteEndPoint}", 
                    _localEndPoint, _remoteEndPoint);
                
                ConnectionStatusChanged?.Invoke(this, new ConnectionStatusChangedEventArgs(true, "连接成功"));

                // 启动数据接收监听
                _ = Task.Run(ListenForDataAsync, _cancellationTokenSource.Token);

                return true;
            }
            catch (Exception ex)
            {
                LogError("UDP连接失败", ex);
                OnErrorOccurred("UDP连接失败", ex);
                await CleanupConnectionAsync();
                return false;
            }
        }

        public async Task<bool> DisconnectAsync()
        {
            ThrowIfDisposed();

            try
            {
                if (!IsConnected)
                {
                    LogWarning("UDP未连接");
                    return true;
                }

                await CleanupConnectionAsync();

                LogInformation("UDP断开连接成功");
                ConnectionStatusChanged?.Invoke(this, new ConnectionStatusChangedEventArgs(false, "断开连接"));

                return true;
            }
            catch (Exception ex)
            {
                LogError("UDP断开连接失败", ex);
                OnErrorOccurred("UDP断开连接失败", ex);
                return false;
            }
        }

        public async Task<CommunicationResult> SendAsync(byte[] data)
        {
            ThrowIfDisposed();

            if (data == null || data.Length == 0)
                return CommunicationResult.Failure("发送数据为空");

            if (!IsConnected || _udpClient == null || _remoteEndPoint == null)
                return CommunicationResult.Failure("UDP未连接");

            var stopwatch = System.Diagnostics.Stopwatch.StartNew();

            try
            {
                await _sendSemaphore.WaitAsync();

                using var timeoutCts = new CancellationTokenSource(Configuration.SendTimeout);
                int bytesSent = await _udpClient.SendAsync(data, data.Length, _remoteEndPoint);

                if (bytesSent != data.Length)
                {
                    stopwatch.Stop();
                    return CommunicationResult.Failure($"发送数据不完整: 期望={data.Length}, 实际={bytesSent}", 
                        elapsedMilliseconds: stopwatch.ElapsedMilliseconds);
                }

                LogDebug("发送数据到 {RemoteEndPoint}: {Data}", _remoteEndPoint, CommunicationUtils.BytesToHexString(data));

                stopwatch.Stop();
                return CommunicationResult.Success(elapsedMilliseconds: stopwatch.ElapsedMilliseconds);
            }
            catch (Exception ex)
            {
                stopwatch.Stop();
                LogError("发送数据失败", ex);
                return CommunicationResult.Failure("发送数据失败", ex, stopwatch.ElapsedMilliseconds);
            }
            finally
            {
                _sendSemaphore.Release();
            }
        }

        public async Task<CommunicationResult> ReadAsync(int timeout = 5000)
        {
            ThrowIfDisposed();

            if (!IsConnected || _udpClient == null)
                return CommunicationResult.Failure("UDP未连接");

            var stopwatch = System.Diagnostics.Stopwatch.StartNew();

            try
            {
                await _readSemaphore.WaitAsync();

                using var timeoutCts = new CancellationTokenSource(timeout);
                var result = await _udpClient.ReceiveAsync().WaitAsync(timeoutCts.Token);

                LogDebug("接收数据从 {RemoteEndPoint}: {Data}", 
                    result.RemoteEndPoint, CommunicationUtils.BytesToHexString(result.Buffer));

                stopwatch.Stop();
                return CommunicationResult.Success(result.Buffer, stopwatch.ElapsedMilliseconds);
            }
            catch (OperationCanceledException)
            {
                stopwatch.Stop();
                return CommunicationResult.Failure("接收数据超时", elapsedMilliseconds: stopwatch.ElapsedMilliseconds);
            }
            catch (Exception ex)
            {
                stopwatch.Stop();
                LogError("接收数据失败", ex);
                return CommunicationResult.Failure("接收数据失败", ex, stopwatch.ElapsedMilliseconds);
            }
            finally
            {
                _readSemaphore.Release();
            }
        }

        public async Task<CommunicationResult> SendAndReceiveAsync(byte[] data, int timeout = 5000)
        {
            var sendResult = await SendAsync(data);
            if (!sendResult.IsSuccess)
                return sendResult;

            // UDP是无连接协议，发送后立即等待响应
            return await ReadAsync(timeout);
        }

        /// <summary>
        /// 发送数据到指定端点
        /// </summary>
        /// <param name="data">数据</param>
        /// <param name="remoteEndPoint">远程端点</param>
        /// <returns>发送结果</returns>
        public async Task<CommunicationResult> SendToAsync(byte[] data, IPEndPoint remoteEndPoint)
        {
            ThrowIfDisposed();

            if (data == null || data.Length == 0)
                return CommunicationResult.Failure("发送数据为空");

            if (!IsConnected || _udpClient == null)
                return CommunicationResult.Failure("UDP未连接");

            var stopwatch = System.Diagnostics.Stopwatch.StartNew();

            try
            {
                await _sendSemaphore.WaitAsync();

                using var timeoutCts = new CancellationTokenSource(Configuration.SendTimeout);
                int bytesSent = await _udpClient.SendAsync(data, data.Length, remoteEndPoint);

                if (bytesSent != data.Length)
                {
                    stopwatch.Stop();
                    return CommunicationResult.Failure($"发送数据不完整: 期望={data.Length}, 实际={bytesSent}",
                        elapsedMilliseconds: stopwatch.ElapsedMilliseconds);
                }

                LogDebug("发送数据到 {RemoteEndPoint}: {Data}", remoteEndPoint, CommunicationUtils.BytesToHexString(data));

                stopwatch.Stop();
                return CommunicationResult.Success(elapsedMilliseconds: stopwatch.ElapsedMilliseconds);
            }
            catch (Exception ex)
            {
                stopwatch.Stop();
                LogError("发送数据失败", ex);
                return CommunicationResult.Failure("发送数据失败", ex, stopwatch.ElapsedMilliseconds);
            }
            finally
            {
                _sendSemaphore.Release();
            }
        }

        private async Task ListenForDataAsync()
        {
            while (!_cancellationTokenSource?.Token.IsCancellationRequested == true && IsConnected)
            {
                try
                {
                    if (_udpClient?.Available > 0)
                    {
                        var result = await _udpClient.ReceiveAsync();
                        DataReceived?.Invoke(this, new DataReceivedEventArgs(result.Buffer, 
                            $"{Configuration.DeviceName} - {result.RemoteEndPoint}"));
                    }

                    await Task.Delay(10, _cancellationTokenSource?.Token ?? CancellationToken.None);
                }
                catch (OperationCanceledException)
                {
                    break;
                }
                catch (Exception ex)
                {
                    OnErrorOccurred("数据接收监听失败", ex);
                    break;
                }
            }
        }

        private async Task CleanupConnectionAsync()
        {
            try
            {
                IsConnected = false;
                _cancellationTokenSource?.Cancel();

                _udpClient?.Close();
                _udpClient?.Dispose();
                _udpClient = null;

                _cancellationTokenSource?.Dispose();
                _cancellationTokenSource = null;
            }
            catch (Exception ex)
            {
                LogError("清理UDP连接资源失败", ex);
            }

            await Task.CompletedTask;
        }

        private void OnErrorOccurred(string message, Exception? exception = null)
        {
            LogError(message, exception);
            ErrorOccurred?.Invoke(this, new CommunicationErrorEventArgs(message, exception, Configuration.DeviceName));
        }

        public override void Dispose()
        {
            if (!_disposed)
            {
                DisconnectAsync().Wait(1000);

                _sendSemaphore?.Dispose();
                _readSemaphore?.Dispose();

                base.Dispose();
            }
        }
    }
}