using System;
using System.Net;
using System.Net.Sockets;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.Extensions.Logging;
using HMI.Communication.Common;
using HMI.Communication.Interfaces;
using HMI.Communication.Models;
using HMI.Communication.Protocols.S7;

namespace HMI.Communication.Implementations
{
    /// <summary>
    /// S7协议通讯实现（基于TCP）
    /// 注意：这是一个简化的S7协议实现，仅用于演示基本功能
    /// </summary>
    public class S7Device : CommunicationBase, ICommunicationDevice
    {
        private TcpClient? _tcpClient;
        private NetworkStream? _networkStream;
        private readonly SemaphoreSlim _sendSemaphore = new(1, 1);
        private readonly SemaphoreSlim _readSemaphore = new(1, 1);
        private CancellationTokenSource? _cancellationTokenSource;
        private bool _isConnected = false;

        public bool IsConnected => _isConnected && _tcpClient?.Connected == true;
        public DeviceConfiguration Configuration { get; }

        public event EventHandler<ConnectionStatusChangedEventArgs>? ConnectionStatusChanged;
        public event EventHandler<DataReceivedEventArgs>? DataReceived;
        public event EventHandler<CommunicationErrorEventArgs>? ErrorOccurred;

        public S7Device(S7Configuration configuration, ILogger<S7Device>? logger = null)
            : base(logger)
        {
            Configuration = configuration ?? throw new ArgumentNullException(nameof(configuration));
        }

        public async Task<bool> ConnectAsync()
        {
            ThrowIfDisposed();

            try
            {
                if (IsConnected)
                {
                    LogWarning("S7已经连接");
                    return true;
                }

                var config = (S7Configuration)Configuration;

                _cancellationTokenSource = new CancellationTokenSource();
                _tcpClient = new TcpClient();

                // 设置超时
                _tcpClient.ReceiveTimeout = config.ReceiveTimeout;
                _tcpClient.SendTimeout = config.SendTimeout;

                var endpoint = new IPEndPoint(IPAddress.Parse(config.IPAddress), config.Port);

                using var timeoutCts = new CancellationTokenSource(config.ConnectionTimeout);
                await _tcpClient.ConnectAsync(endpoint.Address, endpoint.Port, timeoutCts.Token);

                _networkStream = _tcpClient.GetStream();

                // 执行S7连接握手
                if (!await PerformS7HandshakeAsync())
                {
                    await CleanupConnectionAsync();
                    return false;
                }

                _isConnected = true;

                LogInformation("S7连接成功: {IPAddress}:{Port}, Rack={Rack}, Slot={Slot}", 
                    config.IPAddress, config.Port, config.Rack, config.Slot);
                
                ConnectionStatusChanged?.Invoke(this, new ConnectionStatusChangedEventArgs(true, "连接成功"));

                // 启动数据接收监听
                _ = Task.Run(ListenForDataAsync, _cancellationTokenSource.Token);

                return true;
            }
            catch (Exception ex)
            {
                LogError("S7连接失败", ex);
                OnErrorOccurred("S7连接失败", ex);
                await CleanupConnectionAsync();
                return false;
            }
        }

        public async Task<bool> DisconnectAsync()
        {
            ThrowIfDisposed();

            try
            {
                if (!IsConnected)
                {
                    LogWarning("S7未连接");
                    return true;
                }

                await CleanupConnectionAsync();

                LogInformation("S7断开连接成功");
                ConnectionStatusChanged?.Invoke(this, new ConnectionStatusChangedEventArgs(false, "断开连接"));

                return true;
            }
            catch (Exception ex)
            {
                LogError("S7断开连接失败", ex);
                OnErrorOccurred("S7断开连接失败", ex);
                return false;
            }
        }

        public async Task<CommunicationResult> SendAsync(byte[] data)
        {
            ThrowIfDisposed();

            if (data == null || data.Length == 0)
                return CommunicationResult.Failure("发送数据为空");

            if (!IsConnected || _networkStream == null)
                return CommunicationResult.Failure("S7未连接");

            var stopwatch = System.Diagnostics.Stopwatch.StartNew();

            try
            {
                await _sendSemaphore.WaitAsync();

                using var timeoutCts = new CancellationTokenSource(Configuration.SendTimeout);
                await _networkStream.WriteAsync(data, 0, data.Length, timeoutCts.Token);
                await _networkStream.FlushAsync(timeoutCts.Token);

                LogDebug("发送S7数据: {Data}", CommunicationUtils.BytesToHexString(data));

                stopwatch.Stop();
                return CommunicationResult.Success(elapsedMilliseconds: stopwatch.ElapsedMilliseconds);
            }
            catch (Exception ex)
            {
                stopwatch.Stop();
                LogError("发送S7数据失败", ex);
                return CommunicationResult.Failure("发送S7数据失败", ex, stopwatch.ElapsedMilliseconds);
            }
            finally
            {
                _sendSemaphore.Release();
            }
        }

        public async Task<CommunicationResult> ReadAsync(int timeout = 5000)
        {
            ThrowIfDisposed();

            if (!IsConnected || _networkStream == null)
                return CommunicationResult.Failure("S7未连接");

            var stopwatch = System.Diagnostics.Stopwatch.StartNew();

            try
            {
                await _readSemaphore.WaitAsync();

                var buffer = new byte[1024];
                using var timeoutCts = new CancellationTokenSource(timeout);

                int bytesRead = await _networkStream.ReadAsync(buffer, 0, buffer.Length, timeoutCts.Token);

                if (bytesRead > 0)
                {
                    var data = new byte[bytesRead];
                    Array.Copy(buffer, data, bytesRead);

                    LogDebug("接收S7数据: {Data}", CommunicationUtils.BytesToHexString(data));

                    stopwatch.Stop();
                    return CommunicationResult.Success(data, stopwatch.ElapsedMilliseconds);
                }

                stopwatch.Stop();
                return CommunicationResult.Failure("未接收到S7数据", elapsedMilliseconds: stopwatch.ElapsedMilliseconds);
            }
            catch (OperationCanceledException)
            {
                stopwatch.Stop();
                return CommunicationResult.Failure("接收S7数据超时", elapsedMilliseconds: stopwatch.ElapsedMilliseconds);
            }
            catch (Exception ex)
            {
                stopwatch.Stop();
                LogError("接收S7数据失败", ex);
                return CommunicationResult.Failure("接收S7数据失败", ex, stopwatch.ElapsedMilliseconds);
            }
            finally
            {
                _readSemaphore.Release();
            }
        }

        public async Task<CommunicationResult> SendAndReceiveAsync(byte[] data, int timeout = 5000)
        {
            var sendResult = await SendAsync(data);
            if (!sendResult.IsSuccess)
                return sendResult;

            // 等待一小段时间让PLC处理请求
            await Task.Delay(50);

            return await ReadAsync(timeout);
        }

        /// <summary>
        /// 读取DB区域数据
        /// </summary>
        /// <param name="dbNumber">DB号</param>
        /// <param name="startAddress">起始地址</param>
        /// <param name="length">数据长度</param>
        /// <returns>读取结果</returns>
        public async Task<CommunicationResult> ReadDbAsync(ushort dbNumber, uint startAddress, ushort length)
        {
            try
            {
                var request = S7Helper.CreateReadRequest(S7Helper.S7Area.DB, dbNumber, startAddress, length);
                var result = await SendAndReceiveAsync(request);

                if (result.IsSuccess && result.Data != null)
                {
                    var s7Response = S7Helper.ParseResponse(result.Data);
                    if (s7Response.IsValid)
                    {
                        return CommunicationResult.Success(s7Response.Data, result.ElapsedMilliseconds);
                    }
                    else
                    {
                        return CommunicationResult.Failure(s7Response.ErrorMessage ?? "S7响应解析失败");
                    }
                }

                return result;
            }
            catch (Exception ex)
            {
                LogError("读取DB数据失败", ex);
                return CommunicationResult.Failure("读取DB数据失败", ex);
            }
        }

        /// <summary>
        /// 写入DB区域数据
        /// </summary>
        /// <param name="dbNumber">DB号</param>
        /// <param name="startAddress">起始地址</param>
        /// <param name="data">数据</param>
        /// <returns>写入结果</returns>
        public async Task<CommunicationResult> WriteDbAsync(ushort dbNumber, uint startAddress, byte[] data)
        {
            try
            {
                var request = S7Helper.CreateWriteRequest(S7Helper.S7Area.DB, dbNumber, startAddress, data);
                var result = await SendAndReceiveAsync(request);

                if (result.IsSuccess && result.Data != null)
                {
                    var s7Response = S7Helper.ParseResponse(result.Data);
                    if (s7Response.IsValid)
                    {
                        return CommunicationResult.Success(elapsedMilliseconds: result.ElapsedMilliseconds);
                    }
                    else
                    {
                        return CommunicationResult.Failure(s7Response.ErrorMessage ?? "S7响应解析失败");
                    }
                }

                return result;
            }
            catch (Exception ex)
            {
                LogError("写入DB数据失败", ex);
                return CommunicationResult.Failure("写入DB数据失败", ex);
            }
        }

        private async Task<bool> PerformS7HandshakeAsync()
        {
            try
            {
                // 发送连接请求
                var connectionRequest = S7Helper.CreateConnectionRequest();
                await _networkStream!.WriteAsync(connectionRequest, 0, connectionRequest.Length);
                await _networkStream.FlushAsync();

                // 读取响应
                var buffer = new byte[256];
                using var timeoutCts = new CancellationTokenSource(5000);
                int bytesRead = await _networkStream.ReadAsync(buffer, 0, buffer.Length, timeoutCts.Token);

                if (bytesRead > 0)
                {
                    var responseData = new byte[bytesRead];
                    Array.Copy(buffer, responseData, bytesRead);
                    LogDebug("S7握手响应: {Response}", CommunicationUtils.BytesToHexString(responseData));
                    
                    // 简单验证响应（实际实现需要更详细的协议解析）
                    if (bytesRead >= 4 && buffer[0] == 0x03 && buffer[1] == 0x00)
                    {
                        LogInformation("S7握手成功");
                        return true;
                    }
                }

                LogError("S7握手失败：响应无效");
                return false;
            }
            catch (Exception ex)
            {
                LogError("S7握手失败", ex);
                return false;
            }
        }

        private async Task ListenForDataAsync()
        {
            var buffer = new byte[1024];

            while (!_cancellationTokenSource?.Token.IsCancellationRequested == true && IsConnected)
            {
                try
                {
                    if (_networkStream?.DataAvailable == true)
                    {
                        int bytesRead = await _networkStream.ReadAsync(buffer, 0, buffer.Length, _cancellationTokenSource.Token);

                        if (bytesRead > 0)
                        {
                            var data = new byte[bytesRead];
                            Array.Copy(buffer, data, bytesRead);

                            DataReceived?.Invoke(this, new DataReceivedEventArgs(data, Configuration.DeviceName));
                        }
                    }

                    await Task.Delay(10, _cancellationTokenSource.Token);
                }
                catch (OperationCanceledException)
                {
                    break;
                }
                catch (Exception ex)
                {
                    OnErrorOccurred("S7数据接收监听失败", ex);
                    break;
                }
            }
        }

        private async Task CleanupConnectionAsync()
        {
            try
            {
                _isConnected = false;
                _cancellationTokenSource?.Cancel();

                if (_networkStream != null)
                {
                    await _networkStream.DisposeAsync();
                    _networkStream = null;
                }

                _tcpClient?.Close();
                _tcpClient?.Dispose();
                _tcpClient = null;

                _cancellationTokenSource?.Dispose();
                _cancellationTokenSource = null;
            }
            catch (Exception ex)
            {
                LogError("清理S7连接资源失败", ex);
            }
        }

        private void OnErrorOccurred(string message, Exception? exception = null)
        {
            LogError(message, exception);
            ErrorOccurred?.Invoke(this, new CommunicationErrorEventArgs(message, exception, Configuration.DeviceName));
        }

        public override void Dispose()
        {
            if (!_disposed)
            {
                DisconnectAsync().Wait(1000);

                _sendSemaphore?.Dispose();
                _readSemaphore?.Dispose();

                base.Dispose();
            }
        }
    }
}