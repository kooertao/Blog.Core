using System;
using System.Threading.Tasks;
using Microsoft.Extensions.Logging;
using HMI.Communication.Common;
using HMI.Communication.Interfaces;
using HMI.Communication.Models;
using HMI.Communication.Protocols.Modbus;

namespace HMI.Communication.Implementations
{
    /// <summary>
    /// Modbus通讯设备实现
    /// 支持Modbus TCP和Modbus RTU
    /// </summary>
    public class ModbusDevice : CommunicationBase, ICommunicationDevice
    {
        private ICommunicationDevice? _baseDevice;
        private ushort _currentTransactionId = 1;

        public bool IsConnected => _baseDevice?.IsConnected == true;
        public DeviceConfiguration Configuration { get; }

        public event EventHandler<ConnectionStatusChangedEventArgs>? ConnectionStatusChanged;
        public event EventHandler<DataReceivedEventArgs>? DataReceived;
        public event EventHandler<CommunicationErrorEventArgs>? ErrorOccurred;

        public ModbusDevice(ModbusConfiguration configuration, ILogger<ModbusDevice>? logger = null)
            : base(logger)
        {
            Configuration = configuration ?? throw new ArgumentNullException(nameof(configuration));
            InitializeBaseDevice(configuration);
        }

        private void InitializeBaseDevice(ModbusConfiguration config)
        {
            switch (config.ConnectionType)
            {
                case ModbusConnectionType.TCP:
                    var tcpConfig = new TcpConfiguration
                    {
                        DeviceName = config.DeviceName,
                        DeviceId = config.DeviceId,
                        IPAddress = config.IPAddress ?? "127.0.0.1",
                        Port = config.Port,
                        ConnectionTimeout = config.ConnectionTimeout,
                        ReceiveTimeout = config.ReceiveTimeout,
                        SendTimeout = config.SendTimeout,
                        KeepAlive = true
                    };
                    _baseDevice = new TcpDevice(tcpConfig, _logger as ILogger<TcpDevice>);
                    break;

                case ModbusConnectionType.RTU:
                case ModbusConnectionType.ASCII:
                    var serialConfig = new SerialPortConfiguration
                    {
                        DeviceName = config.DeviceName,
                        DeviceId = config.DeviceId,
                        PortName = config.PortName ?? "COM1",
                        BaudRate = config.BaudRate,
                        Parity = config.Parity,
                        DataBits = config.DataBits,
                        StopBits = config.StopBits,
                        ConnectionTimeout = config.ConnectionTimeout,
                        ReceiveTimeout = config.ReceiveTimeout,
                        SendTimeout = config.SendTimeout
                    };
                    _baseDevice = new SerialPortDevice(serialConfig, _logger as ILogger<SerialPortDevice>);
                    break;

                default:
                    throw new ArgumentException($"不支持的Modbus连接类型: {config.ConnectionType}");
            }

            // 转发事件
            _baseDevice.ConnectionStatusChanged += (sender, e) => ConnectionStatusChanged?.Invoke(this, e);
            _baseDevice.DataReceived += OnBaseDeviceDataReceived;
            _baseDevice.ErrorOccurred += (sender, e) => ErrorOccurred?.Invoke(this, e);
        }

        public async Task<bool> ConnectAsync()
        {
            ThrowIfDisposed();

            if (_baseDevice == null)
            {
                LogError("基础通讯设备未初始化");
                return false;
            }

            LogInformation("正在连接Modbus设备: {ConnectionType}", ((ModbusConfiguration)Configuration).ConnectionType);
            return await _baseDevice.ConnectAsync();
        }

        public async Task<bool> DisconnectAsync()
        {
            ThrowIfDisposed();

            if (_baseDevice != null)
            {
                LogInformation("正在断开Modbus设备连接");
                return await _baseDevice.DisconnectAsync();
            }

            return true;
        }

        public async Task<CommunicationResult> SendAsync(byte[] data)
        {
            ThrowIfDisposed();

            if (_baseDevice == null)
                return CommunicationResult.Failure("基础通讯设备未初始化");

            return await _baseDevice.SendAsync(data);
        }

        public async Task<CommunicationResult> ReadAsync(int timeout = 5000)
        {
            ThrowIfDisposed();

            if (_baseDevice == null)
                return CommunicationResult.Failure("基础通讯设备未初始化");

            return await _baseDevice.ReadAsync(timeout);
        }

        public async Task<CommunicationResult> SendAndReceiveAsync(byte[] data, int timeout = 5000)
        {
            var result = await SendAsync(data);
            if (!result.IsSuccess)
                return result;

            // Modbus通常需要短暂延迟
            await Task.Delay(10);

            return await ReadAsync(timeout);
        }

        /// <summary>
        /// 读取保持寄存器
        /// </summary>
        /// <param name="startAddress">起始地址</param>
        /// <param name="quantity">数量</param>
        /// <returns>读取结果</returns>
        public async Task<CommunicationResult> ReadHoldingRegistersAsync(ushort startAddress, ushort quantity)
        {
            ThrowIfDisposed();

            try
            {
                var config = (ModbusConfiguration)Configuration;
                byte[] request;

                if (config.ConnectionType == ModbusConnectionType.TCP)
                {
                    var transactionId = GetNextTransactionId();
                    request = ModbusHelper.CreateTcpReadHoldingRegistersRequest(transactionId, config.SlaveId, startAddress, quantity);
                }
                else
                {
                    request = ModbusHelper.CreateReadHoldingRegistersRequest(config.SlaveId, startAddress, quantity);
                }

                LogDebug("发送Modbus读取保持寄存器请求: 地址={StartAddress}, 数量={Quantity}", startAddress, quantity);

                var result = await SendAndReceiveAsync(request);
                if (!result.IsSuccess || result.Data == null)
                    return result;

                // 解析响应
                ModbusResponse modbusResponse;
                if (config.ConnectionType == ModbusConnectionType.TCP)
                {
                    modbusResponse = ModbusHelper.ParseTcpResponse(result.Data);
                }
                else
                {
                    modbusResponse = ModbusHelper.ParseRtuResponse(result.Data);
                }

                if (!modbusResponse.IsValid)
                {
                    return CommunicationResult.Failure(modbusResponse.ErrorMessage ?? "Modbus响应解析失败");
                }

                LogDebug("成功读取保持寄存器: {Data}", CommunicationUtils.BytesToHexString(modbusResponse.Data ?? Array.Empty<byte>()));

                return CommunicationResult.Success(modbusResponse.Data, result.ElapsedMilliseconds);
            }
            catch (Exception ex)
            {
                LogError("读取保持寄存器失败", ex);
                return CommunicationResult.Failure("读取保持寄存器失败", ex);
            }
        }

        /// <summary>
        /// 写单个寄存器
        /// </summary>
        /// <param name="address">寄存器地址</param>
        /// <param name="value">值</param>
        /// <returns>写入结果</returns>
        public async Task<CommunicationResult> WriteSingleRegisterAsync(ushort address, ushort value)
        {
            ThrowIfDisposed();

            try
            {
                var config = (ModbusConfiguration)Configuration;
                byte[] request;

                if (config.ConnectionType == ModbusConnectionType.TCP)
                {
                    // 为TCP创建写单个寄存器请求
                    var transactionId = GetNextTransactionId();
                    var data = new byte[12];
                    data[0] = (byte)(transactionId >> 8);      // 事务标识符高字节
                    data[1] = (byte)(transactionId & 0xFF);    // 事务标识符低字节
                    data[2] = 0x00;                            // 协议标识符高字节
                    data[3] = 0x00;                            // 协议标识符低字节
                    data[4] = 0x00;                            // 长度高字节
                    data[5] = 0x06;                            // 长度低字节
                    data[6] = config.SlaveId;                  // 单元标识符
                    data[7] = 0x06;                            // 功能码：写单个寄存器
                    data[8] = (byte)(address >> 8);
                    data[9] = (byte)(address & 0xFF);
                    data[10] = (byte)(value >> 8);
                    data[11] = (byte)(value & 0xFF);
                    request = data;
                }
                else
                {
                    request = ModbusHelper.CreateWriteSingleRegisterRequest(config.SlaveId, address, value);
                }

                LogDebug("发送Modbus写单个寄存器请求: 地址={Address}, 值={Value}", address, value);

                var result = await SendAndReceiveAsync(request);
                if (!result.IsSuccess || result.Data == null)
                    return result;

                // 解析响应
                ModbusResponse modbusResponse;
                if (config.ConnectionType == ModbusConnectionType.TCP)
                {
                    modbusResponse = ModbusHelper.ParseTcpResponse(result.Data);
                }
                else
                {
                    modbusResponse = ModbusHelper.ParseRtuResponse(result.Data);
                }

                if (!modbusResponse.IsValid)
                {
                    return CommunicationResult.Failure(modbusResponse.ErrorMessage ?? "Modbus响应解析失败");
                }

                LogDebug("成功写入单个寄存器");

                return CommunicationResult.Success(elapsedMilliseconds: result.ElapsedMilliseconds);
            }
            catch (Exception ex)
            {
                LogError("写入单个寄存器失败", ex);
                return CommunicationResult.Failure("写入单个寄存器失败", ex);
            }
        }

        /// <summary>
        /// 读取输入寄存器
        /// </summary>
        /// <param name="startAddress">起始地址</param>
        /// <param name="quantity">数量</param>
        /// <returns>读取结果</returns>
        public async Task<CommunicationResult> ReadInputRegistersAsync(ushort startAddress, ushort quantity)
        {
            ThrowIfDisposed();

            try
            {
                var config = (ModbusConfiguration)Configuration;
                byte[] request;

                if (config.ConnectionType == ModbusConnectionType.TCP)
                {
                    var transactionId = GetNextTransactionId();
                    var data = new byte[12];
                    data[0] = (byte)(transactionId >> 8);
                    data[1] = (byte)(transactionId & 0xFF);
                    data[2] = 0x00;
                    data[3] = 0x00;
                    data[4] = 0x00;
                    data[5] = 0x06;
                    data[6] = config.SlaveId;
                    data[7] = 0x04; // 功能码：读取输入寄存器
                    data[8] = (byte)(startAddress >> 8);
                    data[9] = (byte)(startAddress & 0xFF);
                    data[10] = (byte)(quantity >> 8);
                    data[11] = (byte)(quantity & 0xFF);
                    request = data;
                }
                else
                {
                    var data = new byte[6];
                    data[0] = config.SlaveId;
                    data[1] = 0x04; // 功能码：读取输入寄存器
                    data[2] = (byte)(startAddress >> 8);
                    data[3] = (byte)(startAddress & 0xFF);
                    data[4] = (byte)(quantity >> 8);
                    data[5] = (byte)(quantity & 0xFF);

                    var crc = ModbusHelper.CalculateCrc16(data);
                    request = new byte[8];
                    Array.Copy(data, request, 6);
                    request[6] = (byte)(crc & 0xFF);
                    request[7] = (byte)(crc >> 8);
                }

                LogDebug("发送Modbus读取输入寄存器请求: 地址={StartAddress}, 数量={Quantity}", startAddress, quantity);

                var result = await SendAndReceiveAsync(request);
                if (!result.IsSuccess || result.Data == null)
                    return result;

                // 解析响应
                ModbusResponse modbusResponse;
                if (config.ConnectionType == ModbusConnectionType.TCP)
                {
                    modbusResponse = ModbusHelper.ParseTcpResponse(result.Data);
                }
                else
                {
                    modbusResponse = ModbusHelper.ParseRtuResponse(result.Data);
                }

                if (!modbusResponse.IsValid)
                {
                    return CommunicationResult.Failure(modbusResponse.ErrorMessage ?? "Modbus响应解析失败");
                }

                LogDebug("成功读取输入寄存器: {Data}", CommunicationUtils.BytesToHexString(modbusResponse.Data ?? Array.Empty<byte>()));

                return CommunicationResult.Success(modbusResponse.Data, result.ElapsedMilliseconds);
            }
            catch (Exception ex)
            {
                LogError("读取输入寄存器失败", ex);
                return CommunicationResult.Failure("读取输入寄存器失败", ex);
            }
        }

        private ushort GetNextTransactionId()
        {
            return _currentTransactionId++;
        }

        private void OnBaseDeviceDataReceived(object? sender, DataReceivedEventArgs e)
        {
            // 对于Modbus，可以在这里进行协议特定的数据处理
            DataReceived?.Invoke(this, e);
        }

        public override void Dispose()
        {
            if (!_disposed)
            {
                _baseDevice?.Dispose();
                base.Dispose();
            }
        }
    }
}