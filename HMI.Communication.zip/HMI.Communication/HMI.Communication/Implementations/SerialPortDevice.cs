using System;
using System.IO.Ports;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.Extensions.Logging;
using HMI.Communication.Common;
using HMI.Communication.Interfaces;
using HMI.Communication.Models;

namespace HMI.Communication.Implementations
{
    /// <summary>
    /// 串口通讯实现
    /// </summary>
    public class SerialPortDevice : CommunicationBase, ICommunicationDevice
    {
        private SerialPort? _serialPort;
        private readonly SemaphoreSlim _sendSemaphore = new(1, 1);
        private readonly SemaphoreSlim _readSemaphore = new(1, 1);

        public bool IsConnected => _serialPort?.IsOpen == true;
        public DeviceConfiguration Configuration { get; }

        public event EventHandler<ConnectionStatusChangedEventArgs>? ConnectionStatusChanged;
        public event EventHandler<DataReceivedEventArgs>? DataReceived;
        public event EventHandler<CommunicationErrorEventArgs>? ErrorOccurred;

        public SerialPortDevice(SerialPortConfiguration configuration, ILogger<SerialPortDevice>? logger = null)
            : base(logger)
        {
            Configuration = configuration ?? throw new ArgumentNullException(nameof(configuration));
        }

        public async Task<bool> ConnectAsync()
        {
            ThrowIfDisposed();

            try
            {
                if (IsConnected)
                {
                    LogWarning("串口已经连接");
                    return true;
                }

                var config = (SerialPortConfiguration)Configuration;
                
                _serialPort = new SerialPort
                {
                    PortName = config.PortName,
                    BaudRate = config.BaudRate,
                    Parity = config.Parity,
                    DataBits = config.DataBits,
                    StopBits = config.StopBits,
                    Handshake = config.Handshake,
                    ReadTimeout = config.ReceiveTimeout,
                    WriteTimeout = config.SendTimeout
                };

                _serialPort.DataReceived += OnDataReceived;
                _serialPort.ErrorReceived += OnErrorReceived;

                await Task.Run(() => _serialPort.Open());

                LogInformation("串口连接成功: {PortName}", config.PortName);
                ConnectionStatusChanged?.Invoke(this, new ConnectionStatusChangedEventArgs(true, "连接成功"));

                return true;
            }
            catch (Exception ex)
            {
                LogError("串口连接失败", ex);
                OnErrorOccurred("串口连接失败", ex);
                return false;
            }
        }

        public async Task<bool> DisconnectAsync()
        {
            ThrowIfDisposed();

            try
            {
                if (!IsConnected)
                {
                    LogWarning("串口未连接");
                    return true;
                }

                await Task.Run(() =>
                {
                    if (_serialPort != null)
                    {
                        _serialPort.DataReceived -= OnDataReceived;
                        _serialPort.ErrorReceived -= OnErrorReceived;
                        _serialPort.Close();
                    }
                });

                LogInformation("串口断开连接成功");
                ConnectionStatusChanged?.Invoke(this, new ConnectionStatusChangedEventArgs(false, "断开连接"));

                return true;
            }
            catch (Exception ex)
            {
                LogError("串口断开连接失败", ex);
                OnErrorOccurred("串口断开连接失败", ex);
                return false;
            }
        }

        public async Task<CommunicationResult> SendAsync(byte[] data)
        {
            ThrowIfDisposed();

            if (data == null || data.Length == 0)
                return CommunicationResult.Failure("发送数据为空");

            if (!IsConnected)
                return CommunicationResult.Failure("串口未连接");

            var stopwatch = System.Diagnostics.Stopwatch.StartNew();

            try
            {
                await _sendSemaphore.WaitAsync();

                await Task.Run(() => _serialPort!.Write(data, 0, data.Length));

                LogDebug("发送数据: {Data}", CommunicationUtils.BytesToHexString(data));

                stopwatch.Stop();
                return CommunicationResult.Success(elapsedMilliseconds: stopwatch.ElapsedMilliseconds);
            }
            catch (Exception ex)
            {
                stopwatch.Stop();
                LogError("发送数据失败", ex);
                return CommunicationResult.Failure("发送数据失败", ex, stopwatch.ElapsedMilliseconds);
            }
            finally
            {
                _sendSemaphore.Release();
            }
        }

        public async Task<CommunicationResult> ReadAsync(int timeout = 5000)
        {
            ThrowIfDisposed();

            if (!IsConnected)
                return CommunicationResult.Failure("串口未连接");

            var stopwatch = System.Diagnostics.Stopwatch.StartNew();

            try
            {
                await _readSemaphore.WaitAsync();

                var buffer = new byte[1024];
                int bytesRead = 0;

                var originalTimeout = _serialPort!.ReadTimeout;
                _serialPort.ReadTimeout = timeout;

                try
                {
                    bytesRead = await Task.Run(() => _serialPort.Read(buffer, 0, buffer.Length));
                }
                finally
                {
                    _serialPort.ReadTimeout = originalTimeout;
                }

                if (bytesRead > 0)
                {
                    var data = new byte[bytesRead];
                    Array.Copy(buffer, data, bytesRead);

                    LogDebug("接收数据: {Data}", CommunicationUtils.BytesToHexString(data));

                    stopwatch.Stop();
                    return CommunicationResult.Success(data, stopwatch.ElapsedMilliseconds);
                }

                stopwatch.Stop();
                return CommunicationResult.Failure("未接收到数据", elapsedMilliseconds: stopwatch.ElapsedMilliseconds);
            }
            catch (TimeoutException)
            {
                stopwatch.Stop();
                return CommunicationResult.Failure("接收数据超时", elapsedMilliseconds: stopwatch.ElapsedMilliseconds);
            }
            catch (Exception ex)
            {
                stopwatch.Stop();
                LogError("接收数据失败", ex);
                return CommunicationResult.Failure("接收数据失败", ex, stopwatch.ElapsedMilliseconds);
            }
            finally
            {
                _readSemaphore.Release();
            }
        }

        public async Task<CommunicationResult> SendAndReceiveAsync(byte[] data, int timeout = 5000)
        {
            var sendResult = await SendAsync(data);
            if (!sendResult.IsSuccess)
                return sendResult;

            // 等待一小段时间让设备处理请求
            await Task.Delay(50);

            return await ReadAsync(timeout);
        }

        private void OnDataReceived(object sender, SerialDataReceivedEventArgs e)
        {
            try
            {
                if (_serialPort?.BytesToRead > 0)
                {
                    var buffer = new byte[_serialPort.BytesToRead];
                    int bytesRead = _serialPort.Read(buffer, 0, buffer.Length);

                    if (bytesRead > 0)
                    {
                        var data = new byte[bytesRead];
                        Array.Copy(buffer, data, bytesRead);

                        DataReceived?.Invoke(this, new DataReceivedEventArgs(data, Configuration.DeviceName));
                    }
                }
            }
            catch (Exception ex)
            {
                OnErrorOccurred("数据接收处理失败", ex);
            }
        }

        private void OnErrorReceived(object sender, SerialErrorReceivedEventArgs e)
        {
            OnErrorOccurred($"串口错误: {e.EventType}");
        }

        private void OnErrorOccurred(string message, Exception? exception = null)
        {
            LogError(message, exception);
            ErrorOccurred?.Invoke(this, new CommunicationErrorEventArgs(message, exception, Configuration.DeviceName));
        }

        public override void Dispose()
        {
            if (!_disposed)
            {
                DisconnectAsync().Wait(1000);

                _serialPort?.Dispose();
                _sendSemaphore?.Dispose();
                _readSemaphore?.Dispose();

                base.Dispose();
            }
        }
    }
}