using System;

namespace HMI.Communication.Protocols.Modbus
{
    /// <summary>
    /// Modbus协议帮助类
    /// </summary>
    public static class ModbusHelper
    {
        /// <summary>
        /// Modbus功能码
        /// </summary>
        public enum FunctionCode : byte
        {
            ReadCoils = 0x01,
            ReadDiscreteInputs = 0x02,
            ReadHoldingRegisters = 0x03,
            ReadInputRegisters = 0x04,
            WriteSingleCoil = 0x05,
            WriteSingleRegister = 0x06,
            WriteMultipleCoils = 0x0F,
            WriteMultipleRegisters = 0x10
        }

        /// <summary>
        /// 创建Modbus RTU读取保持寄存器请求
        /// </summary>
        /// <param name="slaveId">从站地址</param>
        /// <param name="startAddress">起始地址</param>
        /// <param name="quantity">数量</param>
        /// <returns>请求数据包</returns>
        public static byte[] CreateReadHoldingRegistersRequest(byte slaveId, ushort startAddress, ushort quantity)
        {
            var data = new byte[6];
            data[0] = slaveId;
            data[1] = (byte)FunctionCode.ReadHoldingRegisters;
            data[2] = (byte)(startAddress >> 8);
            data[3] = (byte)(startAddress & 0xFF);
            data[4] = (byte)(quantity >> 8);
            data[5] = (byte)(quantity & 0xFF);

            var crc = CalculateCrc16(data);
            var request = new byte[8];
            Array.Copy(data, request, 6);
            request[6] = (byte)(crc & 0xFF);
            request[7] = (byte)(crc >> 8);

            return request;
        }

        /// <summary>
        /// 创建Modbus TCP读取保持寄存器请求
        /// </summary>
        /// <param name="transactionId">事务ID</param>
        /// <param name="slaveId">单元标识符</param>
        /// <param name="startAddress">起始地址</param>
        /// <param name="quantity">数量</param>
        /// <returns>请求数据包</returns>
        public static byte[] CreateTcpReadHoldingRegistersRequest(ushort transactionId, byte slaveId, ushort startAddress, ushort quantity)
        {
            var data = new byte[12];
            data[0] = (byte)(transactionId >> 8);      // 事务标识符高字节
            data[1] = (byte)(transactionId & 0xFF);    // 事务标识符低字节
            data[2] = 0x00;                            // 协议标识符高字节
            data[3] = 0x00;                            // 协议标识符低字节
            data[4] = 0x00;                            // 长度高字节
            data[5] = 0x06;                            // 长度低字节
            data[6] = slaveId;                         // 单元标识符
            data[7] = (byte)FunctionCode.ReadHoldingRegisters;
            data[8] = (byte)(startAddress >> 8);
            data[9] = (byte)(startAddress & 0xFF);
            data[10] = (byte)(quantity >> 8);
            data[11] = (byte)(quantity & 0xFF);

            return data;
        }

        /// <summary>
        /// 创建Modbus RTU写单个寄存器请求
        /// </summary>
        /// <param name="slaveId">从站地址</param>
        /// <param name="address">寄存器地址</param>
        /// <param name="value">值</param>
        /// <returns>请求数据包</returns>
        public static byte[] CreateWriteSingleRegisterRequest(byte slaveId, ushort address, ushort value)
        {
            var data = new byte[6];
            data[0] = slaveId;
            data[1] = (byte)FunctionCode.WriteSingleRegister;
            data[2] = (byte)(address >> 8);
            data[3] = (byte)(address & 0xFF);
            data[4] = (byte)(value >> 8);
            data[5] = (byte)(value & 0xFF);

            var crc = CalculateCrc16(data);
            var request = new byte[8];
            Array.Copy(data, request, 6);
            request[6] = (byte)(crc & 0xFF);
            request[7] = (byte)(crc >> 8);

            return request;
        }

        /// <summary>
        /// 解析Modbus RTU响应
        /// </summary>
        /// <param name="response">响应数据</param>
        /// <returns>解析结果</returns>
        public static ModbusResponse ParseRtuResponse(byte[] response)
        {
            if (response == null || response.Length < 5)
                return new ModbusResponse { IsValid = false, ErrorMessage = "响应数据长度不足" };

            var slaveId = response[0];
            var functionCode = response[1];

            // 检查是否为错误响应
            if ((functionCode & 0x80) != 0)
            {
                var exceptionCode = response[2];
                return new ModbusResponse
                {
                    IsValid = false,
                    ErrorMessage = $"Modbus异常: 功能码={functionCode:X2}, 异常码={exceptionCode:X2}"
                };
            }

            // 验证CRC
            var dataLength = response.Length - 2;
            var data = new byte[dataLength];
            Array.Copy(response, data, dataLength);
            var expectedCrc = CalculateCrc16(data);
            var actualCrc = (ushort)((response[response.Length - 1] << 8) | response[response.Length - 2]);

            if (expectedCrc != actualCrc)
            {
                return new ModbusResponse
                {
                    IsValid = false,
                    ErrorMessage = $"CRC校验失败: 期望={expectedCrc:X4}, 实际={actualCrc:X4}"
                };
            }

            // 解析数据
            var result = new ModbusResponse { IsValid = true, SlaveId = slaveId, FunctionCode = functionCode };

            if (functionCode == (byte)FunctionCode.ReadHoldingRegisters || functionCode == (byte)FunctionCode.ReadInputRegisters)
            {
                var byteCount = response[2];
                result.Data = new byte[byteCount];
                Array.Copy(response, 3, result.Data, 0, byteCount);
            }

            return result;
        }

        /// <summary>
        /// 解析Modbus TCP响应
        /// </summary>
        /// <param name="response">响应数据</param>
        /// <returns>解析结果</returns>
        public static ModbusResponse ParseTcpResponse(byte[] response)
        {
            if (response == null || response.Length < 9)
                return new ModbusResponse { IsValid = false, ErrorMessage = "TCP响应数据长度不足" };

            var transactionId = (ushort)((response[0] << 8) | response[1]);
            var protocolId = (ushort)((response[2] << 8) | response[3]);
            var length = (ushort)((response[4] << 8) | response[5]);
            var slaveId = response[6];
            var functionCode = response[7];

            // 检查协议标识符
            if (protocolId != 0)
            {
                return new ModbusResponse
                {
                    IsValid = false,
                    ErrorMessage = $"无效的协议标识符: {protocolId}"
                };
            }

            // 检查是否为错误响应
            if ((functionCode & 0x80) != 0)
            {
                var exceptionCode = response[8];
                return new ModbusResponse
                {
                    IsValid = false,
                    ErrorMessage = $"Modbus异常: 功能码={functionCode:X2}, 异常码={exceptionCode:X2}"
                };
            }

            var result = new ModbusResponse
            {
                IsValid = true,
                TransactionId = transactionId,
                SlaveId = slaveId,
                FunctionCode = functionCode
            };

            if (functionCode == (byte)FunctionCode.ReadHoldingRegisters || functionCode == (byte)FunctionCode.ReadInputRegisters)
            {
                var byteCount = response[8];
                result.Data = new byte[byteCount];
                Array.Copy(response, 9, result.Data, 0, byteCount);
            }

            return result;
        }

        /// <summary>
        /// 计算CRC16校验
        /// </summary>
        /// <param name="data">数据</param>
        /// <returns>CRC16值</returns>
        public static ushort CalculateCrc16(byte[] data)
        {
            ushort crc = 0xFFFF;
            foreach (byte b in data)
            {
                crc ^= b;
                for (int i = 0; i < 8; i++)
                {
                    if ((crc & 0x0001) != 0)
                    {
                        crc >>= 1;
                        crc ^= 0xA001;
                    }
                    else
                    {
                        crc >>= 1;
                    }
                }
            }
            return crc;
        }

        /// <summary>
        /// 将字节数组转换为寄存器值数组
        /// </summary>
        /// <param name="data">字节数据</param>
        /// <returns>寄存器值数组</returns>
        public static ushort[] BytesToRegisters(byte[] data)
        {
            if (data.Length % 2 != 0)
                throw new ArgumentException("数据长度必须为偶数");

            var registers = new ushort[data.Length / 2];
            for (int i = 0; i < registers.Length; i++)
            {
                registers[i] = (ushort)((data[i * 2] << 8) | data[i * 2 + 1]);
            }
            return registers;
        }

        /// <summary>
        /// 将寄存器值数组转换为字节数组
        /// </summary>
        /// <param name="registers">寄存器值数组</param>
        /// <returns>字节数据</returns>
        public static byte[] RegistersToBytes(ushort[] registers)
        {
            var data = new byte[registers.Length * 2];
            for (int i = 0; i < registers.Length; i++)
            {
                data[i * 2] = (byte)(registers[i] >> 8);
                data[i * 2 + 1] = (byte)(registers[i] & 0xFF);
            }
            return data;
        }
    }

    /// <summary>
    /// Modbus响应结果
    /// </summary>
    public class ModbusResponse
    {
        public bool IsValid { get; set; }
        public string? ErrorMessage { get; set; }
        public ushort TransactionId { get; set; }
        public byte SlaveId { get; set; }
        public byte FunctionCode { get; set; }
        public byte[]? Data { get; set; }
    }
}