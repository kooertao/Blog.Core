using System;

namespace HMI.Communication.Protocols.S7
{
    /// <summary>
    /// S7协议帮助类（简化版本）
    /// 注意：这是一个简化的S7协议实现，完整实现需要更多的协议细节
    /// </summary>
    public static class S7Helper
    {
        /// <summary>
        /// S7数据区域
        /// </summary>
        public enum S7Area : byte
        {
            SystemInfo = 0x03,      // System info of 200 family
            SystemFlags = 0x05,     // System flags of 200 family
            AnalogInputs = 0x06,    // Analog inputs of 200 family
            AnalogOutputs = 0x07,   // Analog outputs of 200 family
            Counters = 0x1C,        // Counters
            Timers = 0x1D,          // Timers
            IPI = 0x81,            // IPI
            Inputs = 0x82,         // Inputs
            Outputs = 0x83,        // Outputs
            Flags = 0x84,          // Flags
            DB = 0x84,             // Data blocks
            DI = 0x85,             // Instance data blocks
            Local = 0x86,          // Local data (should not be used)
            V = 0x87,              // Previous (Vorgänger) local data (should not be used)
        }

        /// <summary>
        /// S7数据类型
        /// </summary>
        public enum S7DataType : byte
        {
            Bit = 0x01,
            Byte = 0x02,
            Char = 0x03,
            Word = 0x04,
            Int = 0x05,
            DWord = 0x06,
            DInt = 0x07,
            Real = 0x08,
            Counter = 0x1C,
            Timer = 0x1D
        }

        /// <summary>
        /// 创建S7连接请求
        /// </summary>
        /// <returns>连接请求数据包</returns>
        public static byte[] CreateConnectionRequest()
        {
            return new byte[]
            {
                // TPKT Header
                0x03, 0x00,
                0x00, 0x16, // Length
                
                // COTP Header
                0x11,       // Length
                0xE0,       // PDU Type
                0x00, 0x00, // Destination Reference
                0x00, 0x01, // Source Reference
                0x00,       // Class + Option
                
                // S7 Communication Setup
                0xC0,       // Setup communication
                0x01,       // Protocol ID
                0x0A,       // Reserved
                0xC1,       // Setup communication
                0x02,       // Max AMQ calling
                0x01,       // Max AMQ called
                0xC2,       // PDU length requested
                0x02,       // PDU length (high)
                0x00,       // PDU length (low)
                0x00
            };
        }

        /// <summary>
        /// 创建读取数据请求
        /// </summary>
        /// <param name="area">数据区域</param>
        /// <param name="dbNumber">DB号（如果不是DB区域则为0）</param>
        /// <param name="startAddress">起始地址</param>
        /// <param name="length">数据长度</param>
        /// <param name="dataType">数据类型</param>
        /// <returns>读取请求数据包</returns>
        public static byte[] CreateReadRequest(S7Area area, ushort dbNumber, uint startAddress, ushort length, S7DataType dataType = S7DataType.Byte)
        {
            var packet = new byte[]
            {
                // TPKT Header
                0x03, 0x00,
                0x00, 0x1F, // Length
                
                // COTP Header
                0x02,       // Length
                0xF0,       // PDU Type
                0x80,       // TPDU Number
                
                // S7 Header
                0x32,       // Protocol ID
                0x01,       // ROSCTR (Job)
                0x00, 0x00, // Redundancy identification
                0x00, 0x00, // PDU Reference
                0x00, 0x0E, // Parameters length
                0x00, 0x00, // Data length
                
                // S7 Parameters
                0x04,       // Function: Read Var
                0x01,       // Item count
                
                // Item specification
                0x12,       // Variable specification
                0x0A,       // Length of following address specification
                0x10,       // Syntax ID
                (byte)dataType, // Transport size
                (byte)(length >> 8), (byte)(length & 0xFF), // Length
                (byte)(dbNumber >> 8), (byte)(dbNumber & 0xFF), // DB number
                (byte)area, // Area
                (byte)(startAddress >> 16), (byte)(startAddress >> 8), (byte)(startAddress & 0xFF) // Address
            };

            return packet;
        }

        /// <summary>
        /// 创建写入数据请求
        /// </summary>
        /// <param name="area">数据区域</param>
        /// <param name="dbNumber">DB号</param>
        /// <param name="startAddress">起始地址</param>
        /// <param name="data">要写入的数据</param>
        /// <param name="dataType">数据类型</param>
        /// <returns>写入请求数据包</returns>
        public static byte[] CreateWriteRequest(S7Area area, ushort dbNumber, uint startAddress, byte[] data, S7DataType dataType = S7DataType.Byte)
        {
            if (data == null || data.Length == 0)
                throw new ArgumentException("数据不能为空");

            var parameterLength = 14;
            var dataLength = 4 + data.Length + (data.Length % 2); // Data header + data + padding
            var totalLength = 19 + parameterLength + dataLength;

            var packet = new byte[totalLength];
            var index = 0;

            // TPKT Header
            packet[index++] = 0x03;
            packet[index++] = 0x00;
            packet[index++] = (byte)(totalLength >> 8);
            packet[index++] = (byte)(totalLength & 0xFF);

            // COTP Header
            packet[index++] = 0x02;
            packet[index++] = 0xF0;
            packet[index++] = 0x80;

            // S7 Header
            packet[index++] = 0x32; // Protocol ID
            packet[index++] = 0x01; // ROSCTR (Job)
            packet[index++] = 0x00; // Redundancy identification
            packet[index++] = 0x00;
            packet[index++] = 0x00; // PDU Reference
            packet[index++] = 0x00;
            packet[index++] = (byte)(parameterLength >> 8); // Parameters length
            packet[index++] = (byte)(parameterLength & 0xFF);
            packet[index++] = (byte)(dataLength >> 8); // Data length
            packet[index++] = (byte)(dataLength & 0xFF);

            // S7 Parameters
            packet[index++] = 0x05; // Function: Write Var
            packet[index++] = 0x01; // Item count

            // Item specification
            packet[index++] = 0x12; // Variable specification
            packet[index++] = 0x0A; // Length of following address specification
            packet[index++] = 0x10; // Syntax ID
            packet[index++] = (byte)dataType; // Transport size
            packet[index++] = (byte)(data.Length >> 8); // Length
            packet[index++] = (byte)(data.Length & 0xFF);
            packet[index++] = (byte)(dbNumber >> 8); // DB number
            packet[index++] = (byte)(dbNumber & 0xFF);
            packet[index++] = (byte)area; // Area
            packet[index++] = (byte)(startAddress >> 16); // Address
            packet[index++] = (byte)(startAddress >> 8);
            packet[index++] = (byte)(startAddress & 0xFF);

            // S7 Data
            packet[index++] = 0x00; // Reserved
            packet[index++] = 0x04; // Transport size
            packet[index++] = (byte)(data.Length >> 8); // Data length
            packet[index++] = (byte)(data.Length & 0xFF);

            // Copy data
            Array.Copy(data, 0, packet, index, data.Length);
            index += data.Length;

            // Add padding if needed
            if (data.Length % 2 != 0)
            {
                packet[index] = 0x00;
            }

            return packet;
        }

        /// <summary>
        /// 解析S7响应
        /// </summary>
        /// <param name="response">响应数据</param>
        /// <returns>解析结果</returns>
        public static S7Response ParseResponse(byte[] response)
        {
            if (response == null || response.Length < 12)
                return new S7Response { IsValid = false, ErrorMessage = "响应数据长度不足" };

            var result = new S7Response();

            try
            {
                // 检查TPKT头
                if (response[0] != 0x03 || response[1] != 0x00)
                {
                    result.ErrorMessage = "无效的TPKT头";
                    return result;
                }

                // 跳过TPKT和COTP头
                int index = 7;

                // 检查S7协议ID
                if (response[index] != 0x32)
                {
                    result.ErrorMessage = "无效的S7协议ID";
                    return result;
                }

                var rosctr = response[index + 1];
                var errorClass = response[index + 8];
                var errorCode = response[index + 9];

                if (errorClass != 0x00 || errorCode != 0x00)
                {
                    result.ErrorMessage = $"S7错误: 类别={errorClass:X2}, 代码={errorCode:X2}";
                    return result;
                }

                // 解析数据（简化处理）
                if (rosctr == 0x03) // Response
                {
                    var parameterLength = (response[index + 4] << 8) | response[index + 5];
                    var dataLength = (response[index + 6] << 8) | response[index + 7];

                    if (dataLength > 0)
                    {
                        var dataStartIndex = index + 12 + parameterLength + 4; // Skip headers + parameters + data header
                        if (dataStartIndex + dataLength - 4 <= response.Length)
                        {
                            result.Data = new byte[dataLength - 4];
                            Array.Copy(response, dataStartIndex, result.Data, 0, dataLength - 4);
                        }
                    }
                }

                result.IsValid = true;
                return result;
            }
            catch (Exception ex)
            {
                result.ErrorMessage = $"解析响应时发生异常: {ex.Message}";
                return result;
            }
        }

        /// <summary>
        /// 将位地址转换为字节地址
        /// </summary>
        /// <param name="bitAddress">位地址 (如: 0.0, 1.7)</param>
        /// <returns>字节偏移和位偏移</returns>
        public static (uint byteOffset, byte bitOffset) ParseBitAddress(string bitAddress)
        {
            var parts = bitAddress.Split('.');
            if (parts.Length != 2)
                throw new ArgumentException("位地址格式无效，应为 'byte.bit' 格式");

            if (!uint.TryParse(parts[0], out uint byteOffset))
                throw new ArgumentException("无效的字节偏移");

            if (!byte.TryParse(parts[1], out byte bitOffset) || bitOffset > 7)
                throw new ArgumentException("无效的位偏移，应为0-7");

            return (byteOffset, bitOffset);
        }

        /// <summary>
        /// 将字节数据转换为16位整数数组
        /// </summary>
        /// <param name="data">字节数据</param>
        /// <returns>整数数组</returns>
        public static short[] BytesToInt16Array(byte[] data)
        {
            if (data.Length % 2 != 0)
                throw new ArgumentException("数据长度必须为偶数");

            var result = new short[data.Length / 2];
            for (int i = 0; i < result.Length; i++)
            {
                result[i] = (short)((data[i * 2] << 8) | data[i * 2 + 1]);
            }
            return result;
        }

        /// <summary>
        /// 将16位整数数组转换为字节数据
        /// </summary>
        /// <param name="values">整数数组</param>
        /// <returns>字节数据</returns>
        public static byte[] Int16ArrayToBytes(short[] values)
        {
            var result = new byte[values.Length * 2];
            for (int i = 0; i < values.Length; i++)
            {
                result[i * 2] = (byte)(values[i] >> 8);
                result[i * 2 + 1] = (byte)(values[i] & 0xFF);
            }
            return result;
        }
    }

    /// <summary>
    /// S7响应结果
    /// </summary>
    public class S7Response
    {
        public bool IsValid { get; set; }
        public string? ErrorMessage { get; set; }
        public byte[]? Data { get; set; }
    }
}