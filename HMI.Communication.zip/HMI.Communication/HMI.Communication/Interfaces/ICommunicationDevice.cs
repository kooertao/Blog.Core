using System;
using System.Threading.Tasks;
using HMI.Communication.Models;

namespace HMI.Communication.Interfaces
{
    /// <summary>
    /// 通讯设备基础接口，定义所有通讯协议的共同行为
    /// </summary>
    public interface ICommunicationDevice : IDisposable
    {
        /// <summary>
        /// 设备连接状态
        /// </summary>
        bool IsConnected { get; }

        /// <summary>
        /// 设备配置信息
        /// </summary>
        DeviceConfiguration Configuration { get; }

        /// <summary>
        /// 连接状态变更事件
        /// </summary>
        event EventHandler<ConnectionStatusChangedEventArgs> ConnectionStatusChanged;

        /// <summary>
        /// 数据接收事件
        /// </summary>
        event EventHandler<DataReceivedEventArgs> DataReceived;

        /// <summary>
        /// 错误发生事件
        /// </summary>
        event EventHandler<CommunicationErrorEventArgs> ErrorOccurred;

        /// <summary>
        /// 连接设备
        /// </summary>
        /// <returns></returns>
        Task<bool> ConnectAsync();

        /// <summary>
        /// 断开连接
        /// </summary>
        /// <returns></returns>
        Task<bool> DisconnectAsync();

        /// <summary>
        /// 发送数据
        /// </summary>
        /// <param name="data">要发送的数据</param>
        /// <returns>发送结果</returns>
        Task<CommunicationResult> SendAsync(byte[] data);

        /// <summary>
        /// 读取数据
        /// </summary>
        /// <param name="timeout">超时时间（毫秒）</param>
        /// <returns>读取到的数据</returns>
        Task<CommunicationResult> ReadAsync(int timeout = 5000);

        /// <summary>
        /// 发送数据并等待响应
        /// </summary>
        /// <param name="data">要发送的数据</param>
        /// <param name="timeout">超时时间（毫秒）</param>
        /// <returns>响应数据</returns>
        Task<CommunicationResult> SendAndReceiveAsync(byte[] data, int timeout = 5000);
    }
}