using System;

namespace HMI.Communication.Common
{
    /// <summary>
    /// 通用工具类
    /// </summary>
    public static class CommunicationUtils
    {
        /// <summary>
        /// 将字节数组转换为十六进制字符串
        /// </summary>
        /// <param name="data">字节数组</param>
        /// <param name="separator">分隔符</param>
        /// <returns>十六进制字符串</returns>
        public static string BytesToHexString(byte[] data, string separator = " ")
        {
            if (data == null || data.Length == 0)
                return string.Empty;

            return BitConverter.ToString(data).Replace("-", separator);
        }

        /// <summary>
        /// 将十六进制字符串转换为字节数组
        /// </summary>
        /// <param name="hex">十六进制字符串</param>
        /// <returns>字节数组</returns>
        public static byte[] HexStringToBytes(string hex)
        {
            if (string.IsNullOrEmpty(hex))
                return Array.Empty<byte>();

            // 移除空格和分隔符
            hex = hex.Replace(" ", "").Replace("-", "").Replace(":", "");

            if (hex.Length % 2 != 0)
                throw new ArgumentException("十六进制字符串长度必须为偶数");

            byte[] result = new byte[hex.Length / 2];
            for (int i = 0; i < result.Length; i++)
            {
                result[i] = Convert.ToByte(hex.Substring(i * 2, 2), 16);
            }

            return result;
        }

        /// <summary>
        /// 计算CRC16校验
        /// </summary>
        /// <param name="data">数据</param>
        /// <returns>CRC16值</returns>
        public static ushort CalculateCrc16(byte[] data)
        {
            ushort crc = 0xFFFF;
            foreach (byte b in data)
            {
                crc ^= b;
                for (int i = 0; i < 8; i++)
                {
                    if ((crc & 0x0001) != 0)
                    {
                        crc >>= 1;
                        crc ^= 0xA001;
                    }
                    else
                    {
                        crc >>= 1;
                    }
                }
            }
            return crc;
        }

        /// <summary>
        /// 计算LRC校验
        /// </summary>
        /// <param name="data">数据</param>
        /// <returns>LRC值</returns>
        public static byte CalculateLrc(byte[] data)
        {
            byte lrc = 0;
            foreach (byte b in data)
            {
                lrc += b;
            }
            return (byte)(-lrc);
        }

        /// <summary>
        /// 检查IP地址格式是否正确
        /// </summary>
        /// <param name="ipAddress">IP地址</param>
        /// <returns>是否有效</returns>
        public static bool IsValidIPAddress(string ipAddress)
        {
            return System.Net.IPAddress.TryParse(ipAddress, out _);
        }

        /// <summary>
        /// 检查端口号是否有效
        /// </summary>
        /// <param name="port">端口号</param>
        /// <returns>是否有效</returns>
        public static bool IsValidPort(int port)
        {
            return port >= 1 && port <= 65535;
        }

        /// <summary>
        /// 生成事务ID（用于Modbus TCP等协议）
        /// </summary>
        /// <returns>事务ID</returns>
        public static ushort GenerateTransactionId()
        {
            return (ushort)Random.Shared.Next(1, 65536);
        }

        /// <summary>
        /// 将16位整数转换为字节数组（大端序）
        /// </summary>
        /// <param name="value">16位整数</param>
        /// <returns>字节数组</returns>
        public static byte[] UInt16ToBigEndianBytes(ushort value)
        {
            return new byte[] { (byte)(value >> 8), (byte)(value & 0xFF) };
        }

        /// <summary>
        /// 将字节数组转换为16位整数（大端序）
        /// </summary>
        /// <param name="bytes">字节数组</param>
        /// <param name="offset">偏移量</param>
        /// <returns>16位整数</returns>
        public static ushort BigEndianBytesToUInt16(byte[] bytes, int offset = 0)
        {
            if (bytes.Length < offset + 2)
                throw new ArgumentException("字节数组长度不足");

            return (ushort)((bytes[offset] << 8) | bytes[offset + 1]);
        }
    }
}