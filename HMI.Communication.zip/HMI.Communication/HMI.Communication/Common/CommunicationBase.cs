using Microsoft.Extensions.Logging;

namespace HMI.Communication.Common
{
    /// <summary>
    /// 通讯基类，提供共同的功能
    /// </summary>
    public abstract class CommunicationBase
    {
        protected readonly ILogger? _logger;
        protected readonly object _lockObject = new object();
        protected volatile bool _disposed = false;

        protected CommunicationBase(ILogger? logger = null)
        {
            _logger = logger;
        }

        /// <summary>
        /// 记录信息日志
        /// </summary>
        /// <param name="message">消息</param>
        /// <param name="args">参数</param>
        protected virtual void LogInformation(string message, params object[] args)
        {
            _logger?.LogInformation(message, args);
        }

        /// <summary>
        /// 记录警告日志
        /// </summary>
        /// <param name="message">消息</param>
        /// <param name="args">参数</param>
        protected virtual void LogWarning(string message, params object[] args)
        {
            _logger?.LogWarning(message, args);
        }

        /// <summary>
        /// 记录错误日志
        /// </summary>
        /// <param name="message">消息</param>
        /// <param name="exception">异常</param>
        /// <param name="args">参数</param>
        protected virtual void LogError(string message, Exception? exception = null, params object[] args)
        {
            _logger?.LogError(exception, message, args);
        }

        /// <summary>
        /// 记录调试日志
        /// </summary>
        /// <param name="message">消息</param>
        /// <param name="args">参数</param>
        protected virtual void LogDebug(string message, params object[] args)
        {
            _logger?.LogDebug(message, args);
        }

        /// <summary>
        /// 检查是否已释放
        /// </summary>
        /// <exception cref="ObjectDisposedException"></exception>
        protected virtual void ThrowIfDisposed()
        {
            if (_disposed)
            {
                throw new ObjectDisposedException(GetType().Name);
            }
        }

        /// <summary>
        /// 释放资源
        /// </summary>
        public virtual void Dispose()
        {
            if (!_disposed)
            {
                _disposed = true;
                GC.SuppressFinalize(this);
            }
        }
    }
}