using System;

namespace HMI.Communication.Models
{
    /// <summary>
    /// 设备配置基类
    /// </summary>
    public abstract class DeviceConfiguration
    {
        /// <summary>
        /// 设备名称
        /// </summary>
        public string DeviceName { get; set; } = string.Empty;

        /// <summary>
        /// 设备ID
        /// </summary>
        public string DeviceId { get; set; } = string.Empty;

        /// <summary>
        /// 连接超时时间（毫秒）
        /// </summary>
        public int ConnectionTimeout { get; set; } = 5000;

        /// <summary>
        /// 接收超时时间（毫秒）
        /// </summary>
        public int ReceiveTimeout { get; set; } = 3000;

        /// <summary>
        /// 发送超时时间（毫秒）
        /// </summary>
        public int SendTimeout { get; set; } = 3000;

        /// <summary>
        /// 重试次数
        /// </summary>
        public int RetryCount { get; set; } = 3;

        /// <summary>
        /// 重试间隔（毫秒）
        /// </summary>
        public int RetryInterval { get; set; } = 1000;

        /// <summary>
        /// 是否启用日志
        /// </summary>
        public bool EnableLogging { get; set; } = true;
    }

    /// <summary>
    /// 串口配置
    /// </summary>
    public class SerialPortConfiguration : DeviceConfiguration
    {
        public string PortName { get; set; } = "COM1";
        public int BaudRate { get; set; } = 9600;
        public System.IO.Ports.Parity Parity { get; set; } = System.IO.Ports.Parity.None;
        public int DataBits { get; set; } = 8;
        public System.IO.Ports.StopBits StopBits { get; set; } = System.IO.Ports.StopBits.One;
        public System.IO.Ports.Handshake Handshake { get; set; } = System.IO.Ports.Handshake.None;
    }

    /// <summary>
    /// TCP配置
    /// </summary>
    public class TcpConfiguration : DeviceConfiguration
    {
        public string IPAddress { get; set; } = "127.0.0.1";
        public int Port { get; set; } = 502;
        public bool KeepAlive { get; set; } = true;
        public int KeepAliveTime { get; set; } = 2000;
        public int KeepAliveInterval { get; set; } = 1000;
    }

    /// <summary>
    /// UDP配置
    /// </summary>
    public class UdpConfiguration : DeviceConfiguration
    {
        public string IPAddress { get; set; } = "127.0.0.1";
        public int Port { get; set; } = 502;
        public string LocalIPAddress { get; set; } = "0.0.0.0";
        public int LocalPort { get; set; } = 0;
    }

    /// <summary>
    /// Modbus配置
    /// </summary>
    public class ModbusConfiguration : DeviceConfiguration
    {
        public byte SlaveId { get; set; } = 1;
        public ModbusConnectionType ConnectionType { get; set; } = ModbusConnectionType.TCP;
        
        // TCP specific
        public string? IPAddress { get; set; } = "127.0.0.1";
        public int Port { get; set; } = 502;
        
        // Serial specific
        public string? PortName { get; set; } = "COM1";
        public int BaudRate { get; set; } = 9600;
        public System.IO.Ports.Parity Parity { get; set; } = System.IO.Ports.Parity.None;
        public int DataBits { get; set; } = 8;
        public System.IO.Ports.StopBits StopBits { get; set; } = System.IO.Ports.StopBits.One;
    }

    /// <summary>
    /// S7配置
    /// </summary>
    public class S7Configuration : DeviceConfiguration
    {
        public string IPAddress { get; set; } = "192.168.1.1";
        public int Port { get; set; } = 102;
        public int Rack { get; set; } = 0;
        public int Slot { get; set; } = 1;
        public S7PlcType PlcType { get; set; } = S7PlcType.S7_1200;
    }

    /// <summary>
    /// Modbus连接类型
    /// </summary>
    public enum ModbusConnectionType
    {
        TCP,
        RTU,
        ASCII
    }

    /// <summary>
    /// S7 PLC类型
    /// </summary>
    public enum S7PlcType
    {
        S7_200,
        S7_300,
        S7_400,
        S7_1200,
        S7_1500
    }
}