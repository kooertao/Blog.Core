using System;

namespace HMI.Communication.Models
{
    /// <summary>
    /// 通讯结果
    /// </summary>
    public class CommunicationResult
    {
        /// <summary>
        /// 操作是否成功
        /// </summary>
        public bool IsSuccess { get; set; }

        /// <summary>
        /// 接收到的数据
        /// </summary>
        public byte[]? Data { get; set; }

        /// <summary>
        /// 错误消息
        /// </summary>
        public string? ErrorMessage { get; set; }

        /// <summary>
        /// 异常信息
        /// </summary>
        public Exception? Exception { get; set; }

        /// <summary>
        /// 操作耗时（毫秒）
        /// </summary>
        public long ElapsedMilliseconds { get; set; }

        /// <summary>
        /// 操作时间戳
        /// </summary>
        public DateTime Timestamp { get; set; } = DateTime.Now;

        /// <summary>
        /// 创建成功结果
        /// </summary>
        /// <param name="data">数据</param>
        /// <param name="elapsedMilliseconds">耗时</param>
        /// <returns></returns>
        public static CommunicationResult Success(byte[]? data = null, long elapsedMilliseconds = 0)
        {
            return new CommunicationResult
            {
                IsSuccess = true,
                Data = data,
                ElapsedMilliseconds = elapsedMilliseconds
            };
        }

        /// <summary>
        /// 创建失败结果
        /// </summary>
        /// <param name="errorMessage">错误消息</param>
        /// <param name="exception">异常</param>
        /// <param name="elapsedMilliseconds">耗时</param>
        /// <returns></returns>
        public static CommunicationResult Failure(string errorMessage, Exception? exception = null, long elapsedMilliseconds = 0)
        {
            return new CommunicationResult
            {
                IsSuccess = false,
                ErrorMessage = errorMessage,
                Exception = exception,
                ElapsedMilliseconds = elapsedMilliseconds
            };
        }
    }

    /// <summary>
    /// 连接状态变更事件参数
    /// </summary>
    public class ConnectionStatusChangedEventArgs : EventArgs
    {
        public bool IsConnected { get; set; }
        public string? Message { get; set; }
        public DateTime Timestamp { get; set; } = DateTime.Now;

        public ConnectionStatusChangedEventArgs(bool isConnected, string? message = null)
        {
            IsConnected = isConnected;
            Message = message;
        }
    }

    /// <summary>
    /// 数据接收事件参数
    /// </summary>
    public class DataReceivedEventArgs : EventArgs
    {
        public byte[] Data { get; set; }
        public DateTime Timestamp { get; set; } = DateTime.Now;
        public string? Source { get; set; }

        public DataReceivedEventArgs(byte[] data, string? source = null)
        {
            Data = data;
            Source = source;
        }
    }

    /// <summary>
    /// 通讯错误事件参数
    /// </summary>
    public class CommunicationErrorEventArgs : EventArgs
    {
        public string Message { get; set; }
        public Exception? Exception { get; set; }
        public DateTime Timestamp { get; set; } = DateTime.Now;
        public string? Source { get; set; }

        public CommunicationErrorEventArgs(string message, Exception? exception = null, string? source = null)
        {
            Message = message;
            Exception = exception;
            Source = source;
        }
    }
}