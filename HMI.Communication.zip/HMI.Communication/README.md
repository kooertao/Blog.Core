# HMI通讯库 (HMI.Communication)

一个功能强大的C#上位机通讯库，支持多种工业通讯协议，包括串口、TCP、UDP、Modbus和S7协议。

## 特性

- 🔌 **多协议支持**: 串口、TCP、UDP、Modbus RTU/TCP、S7协议
- 🎯 **统一接口**: 所有通讯协议实现统一的`ICommunicationDevice`接口
- 📊 **事件驱动**: 支持连接状态变更、数据接收和错误事件
- 🔧 **可配置**: 丰富的配置选项，支持各种通讯参数
- 📝 **完善日志**: 集成Microsoft.Extensions.Logging，支持详细日志记录
- ⚡ **异步操作**: 全异步API，提高应用程序响应性
- 🛡️ **错误处理**: 完善的错误处理和重试机制

## 支持的协议

### 1. 串口通讯 (SerialPortDevice)
- 支持RS232/RS485通讯
- 可配置波特率、数据位、停止位、校验位
- 自动处理数据接收事件

### 2. TCP通讯 (TcpDevice)
- 支持TCP客户端模式
- KeepAlive机制
- 自动重连支持

### 3. UDP通讯 (UdpDevice)
- 支持UDP通讯
- 可指定本地和远程端点
- 支持广播和单播

### 4. Modbus协议 (ModbusDevice)
- 支持Modbus RTU（串口）和Modbus TCP
- 实现常用功能码：读保持寄存器、写单个寄存器、读输入寄存器
- 自动CRC校验（RTU模式）
- 支持多从站通讯

### 5. S7协议 (S7Device)
- 支持西门子S7系列PLC通讯
- 基于TCP连接
- 支持DB区域读写
- 简化的S7协议实现

## 快速开始

### 安装

```bash
# 克隆项目
git clone <repository-url>
cd HMI.Communication

# 编译项目
dotnet build
```

### 基本使用示例

#### 串口通讯
```csharp
var config = new SerialPortConfiguration
{
    DeviceName = "测试设备",
    PortName = "COM1",
    BaudRate = 9600,
    Parity = Parity.None,
    DataBits = 8,
    StopBits = StopBits.One
};

using var device = new SerialPortDevice(config, logger);

// 订阅事件
device.ConnectionStatusChanged += (sender, e) => 
    Console.WriteLine($"连接状态: {(e.IsConnected ? "已连接" : "已断开")}");

device.DataReceived += (sender, e) => 
    Console.WriteLine($"收到数据: {Convert.ToHexString(e.Data)}");

// 连接设备
if (await device.ConnectAsync())
{
    // 发送数据
    var data = new byte[] { 0x01, 0x03, 0x00, 0x00, 0x00, 0x01 };
    var result = await device.SendAsync(data);
    
    if (result.IsSuccess)
    {
        Console.WriteLine("数据发送成功");
    }
}
```

#### Modbus TCP通讯
```csharp
var config = new ModbusConfiguration
{
    DeviceName = "Modbus设备",
    ConnectionType = ModbusConnectionType.TCP,
    IPAddress = "192.168.1.100",
    Port = 502,
    SlaveId = 1
};

using var device = new ModbusDevice(config, logger);

if (await device.ConnectAsync())
{
    // 读取保持寄存器
    var result = await device.ReadHoldingRegistersAsync(0, 10);
    if (result.IsSuccess && result.Data != null)
    {
        var registers = ModbusHelper.BytesToRegisters(result.Data);
        Console.WriteLine($"读取到 {registers.Length} 个寄存器");
    }
    
    // 写入单个寄存器
    await device.WriteSingleRegisterAsync(0, 1234);
}
```

#### S7协议通讯
```csharp
var config = new S7Configuration
{
    DeviceName = "S7 PLC",
    IPAddress = "192.168.1.10",
    Port = 102,
    Rack = 0,
    Slot = 1,
    PlcType = S7PlcType.S7_1200
};

using var device = new S7Device(config, logger);

if (await device.ConnectAsync())
{
    // 读取DB块数据
    var result = await device.ReadDbAsync(1, 0, 10);
    if (result.IsSuccess && result.Data != null)
    {
        Console.WriteLine($"读取DB1数据: {Convert.ToHexString(result.Data)}");
    }
    
    // 写入DB块数据
    var writeData = new byte[] { 0x12, 0x34, 0x56, 0x78 };
    await device.WriteDbAsync(1, 0, writeData);
}
```

## 项目结构

```
HMI.Communication/
├── Common/                 # 公共基类和工具
│   ├── CommunicationBase.cs
│   └── CommunicationUtils.cs
├── Implementations/        # 具体协议实现
│   ├── SerialPortDevice.cs
│   ├── TcpDevice.cs
│   ├── UdpDevice.cs
│   ├── ModbusDevice.cs
│   └── S7Device.cs
├── Interfaces/            # 接口定义
│   └── ICommunicationDevice.cs
├── Models/               # 数据模型
│   ├── CommunicationModels.cs
│   └── DeviceConfiguration.cs
└── Protocols/           # 协议相关
    ├── Modbus/
    │   └── ModbusHelper.cs
    └── S7/
        └── S7Helper.cs
```

## 配置选项

### 通用配置 (DeviceConfiguration)
- `DeviceName`: 设备名称
- `DeviceId`: 设备ID
- `ConnectionTimeout`: 连接超时时间（毫秒）
- `ReceiveTimeout`: 接收超时时间（毫秒）
- `SendTimeout`: 发送超时时间（毫秒）
- `RetryCount`: 重试次数
- `RetryInterval`: 重试间隔（毫秒）
- `EnableLogging`: 是否启用日志

### 串口配置 (SerialPortConfiguration)
继承通用配置，额外包含：
- `PortName`: 串口名称（如COM1）
- `BaudRate`: 波特率
- `Parity`: 校验位
- `DataBits`: 数据位
- `StopBits`: 停止位
- `Handshake`: 握手协议

### TCP配置 (TcpConfiguration)
继承通用配置，额外包含：
- `IPAddress`: IP地址
- `Port`: 端口号
- `KeepAlive`: 是否启用KeepAlive
- `KeepAliveTime`: KeepAlive时间
- `KeepAliveInterval`: KeepAlive间隔

### Modbus配置 (ModbusConfiguration)
继承通用配置，额外包含：
- `SlaveId`: 从站地址
- `ConnectionType`: 连接类型（TCP/RTU/ASCII）
- TCP相关: `IPAddress`, `Port`
- 串口相关: `PortName`, `BaudRate`, `Parity`, `DataBits`, `StopBits`

### S7配置 (S7Configuration)
继承通用配置，额外包含：
- `IPAddress`: PLC IP地址
- `Port`: 端口号（默认102）
- `Rack`: 机架号
- `Slot`: 插槽号
- `PlcType`: PLC类型

## 事件处理

所有通讯设备都支持以下事件：

### ConnectionStatusChanged
连接状态变更事件，包含连接状态和消息。

### DataReceived
数据接收事件，包含接收到的原始数据。

### ErrorOccurred
错误发生事件，包含错误消息和异常信息。

## 日志配置

项目使用Microsoft.Extensions.Logging进行日志记录：

```csharp
using var loggerFactory = LoggerFactory.Create(builder =>
{
    builder.AddConsole()
           .SetMinimumLevel(LogLevel.Debug);
});

var logger = loggerFactory.CreateLogger<SerialPortDevice>();
```

## 最佳实践

1. **使用using语句**: 确保设备资源正确释放
2. **异常处理**: 始终检查操作结果的`IsSuccess`属性
3. **超时设置**: 根据实际网络环境调整超时时间
4. **日志记录**: 启用适当级别的日志以便调试
5. **事件订阅**: 及时处理连接状态和错误事件

## 注意事项

- S7协议实现是简化版本，完整实现需要更多协议细节
- 某些功能可能需要特定的硬件设备进行测试
- 在生产环境中使用前，请充分测试所有功能

## 示例项目

查看`HMI.Communication.Example`项目获取更多使用示例。运行示例：

```bash
dotnet run --project HMI.Communication.Example
```

## 依赖项

- .NET 8.0
- Microsoft.Extensions.Logging
- Microsoft.Extensions.Logging.Console
- System.IO.Ports

## 许可证

本项目基于MIT许可证开源。

## 贡献

欢迎提交Issue和Pull Request！

## 联系方式

如有问题或建议，请通过GitHub Issues联系。